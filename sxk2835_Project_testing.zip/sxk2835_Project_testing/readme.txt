Steps to run the project

Using ECLIPSE

Step-1 OPEN ECLIPSE
Step-2 GO TO FILE > SELECT OPEN PROJECT FROM FILE SYSTEM
Step-3 CLICK ON DIRECTORY 
Step-4 LOCATE THE SUBMITTED FOLDER.
Step-5 DOUBLE CLICK ON THE FOLDER CALLED "Project".
Step-6 DOUBLE CLICK ON THE "JUnit Source_code" FOLDER.
Step-7 SELCT "Printtokens" FOLDER AGAIN
Step-8 PRESS SELECT FOLDER
Step-9 PRESS FINISH
Step-10 RUN THE PROGRAM

Using Terminal

Step-1 GOTO THE DIRECTORY WHERE PRINTTOKENS.JAVA IS LOCATED
Step-2 OPEN TERMINAL IN THAT DIRECTORY
STEP-3 TYPE 
	-"javac -d . Printtokens.java" <<enter>>
	-"java JUnitPrinttokens.Printtokens" <<enter>>- if you want to input values using console else
	-"java JUnitPrinttokens.Printtokens file.txt" <<enter>>- with file.txt in same directory


Infeasible blocks

1. Block 6, 14, 24, 26 in get_token
2. Block 5 in main method.
